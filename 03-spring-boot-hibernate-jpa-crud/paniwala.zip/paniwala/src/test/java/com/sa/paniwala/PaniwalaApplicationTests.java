package com.sa.paniwala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaniwalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
